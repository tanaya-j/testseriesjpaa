package com.cg.testseriesapplicationspringmvc.exception;

public class CandidateNotFoundException extends RuntimeException {

	
	public CandidateNotFoundException() {
		// TODO Auto-generated constructor stub
	}
	
	public CandidateNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	
	
}
