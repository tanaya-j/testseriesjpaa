package com.cg.testseriesapplicationspringmvc.dto;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;




@Entity
@Table(name="Test")
public class Test {
	
	@Id
	@Column(name="test_id")
	private Integer id;
	@Column(name="test_name")
	private String name;
	@Column(name="total_question")
	private BigInteger totalquestions;
	@Column(name="test_marks")
	private BigInteger totalMarks;
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="test_Id")
	private List<Question> questions=new ArrayList<Question>();
	
	
	
	public Test() {
		
	}


	public Test(Integer id, String name, BigInteger totalquestions, BigInteger totalMarks, List<Question> questions) {
		super();
		this.id = id;
		this.name = name;
		this.totalquestions = totalquestions;
		this.totalMarks = totalMarks;
		this.questions = questions;
	}





	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public BigInteger getTotalquestions() {
		return totalquestions;
	}



	public void setTotalquestions(BigInteger totalquestions) {
		this.totalquestions = totalquestions;
	}



	public BigInteger getTotalMarks() {
		return totalMarks;
	}



	public void setTotalMarks(BigInteger totalMarks) {
		this.totalMarks = totalMarks;
	}



	public List<Question> getQuestions() {
		return questions;
	}



	public void setQuestions(List<Question> questions) {
		this.questions = questions;
	}

	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	@Override
	public String toString() {
		return "Test [id=" + id + ", name=" + name + ", totalquestions=" + totalquestions + ", totalMarks=" + totalMarks
				+ ", questions=" + questions + "]";
	}



	
}
