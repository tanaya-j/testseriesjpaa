package com.cg.testseriesapplicationspringmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;
import com.cg.testseriesapplicationspringmvc.dto.Candidate;
import com.cg.testseriesapplicationspringmvc.dto.Question;
import com.cg.testseriesapplicationspringmvc.dto.Test;
import com.cg.testseriesapplicationspringmvc.exception.CandidateNotFoundException;
import com.cg.testseriesapplicationspringmvc.exception.TestNotFoundException;
import com.cg.testseriesapplicationspringmvc.service.CandidateService;
import com.cg.testseriesapplicationspringmvc.service.TestAssignerService;
import com.cg.testseriesapplicationspringmvc.service.TestService;

@Controller
public class TestController {

	@Autowired
	CandidateService service;
	@Autowired
	TestService tservice;
	@Autowired
	TestAssignerService aservice;
	
    Test t;
	/*@RequestMapping(value="login" , method=RequestMethod.GET)
 // @GetMapping(value="login")
	public String loginPage() {
	  System.out.println("hi");
		return "mylogin";
	}
	@PostMapping("checklogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("upass") String pass) {
		//System.out.println("Logged in");
		if (user.equals("admin") && pass.equals("tanaya")) {
			return "listproduct";
		} else {
			return "error";
		}
	 }*/
	
    @RequestMapping(value="main" , method=RequestMethod.GET)
	public String listPage() {
		return "main";
		}

	@GetMapping(value="create")
	public ModelAndView getcreateTest(@ModelAttribute("test") Test test) {
		 return new ModelAndView("createTest");
	}
	
	@PostMapping("createTest")
	public ModelAndView createTest(@ModelAttribute("test") Test test) {
		this.t=test;
		//Test t=tservice.createMyTest(test);
		return new ModelAndView("addq");
		
	}
	
	
	@PostMapping("addq")
	public ModelAndView question(@RequestParam("id") int id,@RequestParam("content") String content,
			@RequestParam("optionA") String optionA,@RequestParam("optionB") String optionB,@RequestParam("optionB") String optionC,
			@RequestParam("correctOption") String correctOption) {
		Question  q=new Question();
		q.setId(id);
		q.setContent(content);
		q.setOptionA(optionA);
		q.setOptionB(optionB);
		q.setOptionC(optionC);
		q.setCorrectOption(correctOption);
		List<Question> myQuestions=new ArrayList<Question>();
		myQuestions.add(q);
		
		Test ts=new Test();
		ts.setId(t.getId());
		ts.setName(t.getName());
		ts.setTotalMarks(t.getTotalMarks());
		ts.setTotalquestions(t.getTotalquestions());
		ts.setQuestions(myQuestions);
		
		Test aTest=tservice.createMyTest(ts);
		
		return new ModelAndView("success","key",aTest);
	}
	

	@GetMapping("find")
	public ModelAndView search() {
		return new ModelAndView("searchTest");
	}
	
	
	@PostMapping("searchTest")
	public ModelAndView searchTrainee(@RequestParam("name") String name,Model model) {
	Test t=tservice.searchTestByName(name);
	model.addAttribute("keyy",t);
	return new ModelAndView("searched");
			}
	
  //  @RequestMapping(value="addcandidates" , method=RequestMethod.GET)
	@GetMapping("addcandidates")
	public ModelAndView getAddCandidate(@ModelAttribute("candidate") Candidate c) {
		
		return new ModelAndView("addCand");
		}
	
	@PostMapping("addCand")
	 public ModelAndView addcandidate(@ModelAttribute("cand") Candidate c) {
//		 System.out.println(pro);
		Candidate ca=service.addCandidate(c);
		return new ModelAndView("main","key",ca);
	 }
	
	@GetMapping("assign")
    public ModelAndView getAssigner(@ModelAttribute("assigner") Assigner assigner) {
		
		return new ModelAndView("assign");
		}
	
    @PostMapping("assign")
	public ModelAndView assign(@ModelAttribute("assigner") Assigner assigner) {
	    Assigner assigned=aservice.assignTestToCandidate(assigner);
		return new ModelAndView("assigned","key",assigned);
	}
    
    
    @ExceptionHandler({TestNotFoundException.class})
    	public ModelAndView handleTestException(TestNotFoundException be) {

    		ModelAndView model = new ModelAndView("error");

    		model.addObject("errMsg", be.getMessage());

    		return model;

    	}  
    	  
    @ExceptionHandler({CandidateNotFoundException.class})
	public ModelAndView handleCandidateException(CandidateNotFoundException be) {

		ModelAndView model = new ModelAndView("error");

		model.addObject("errMsg", be.getMessage());

		return model;

	}   

}
