package com.cg.testseriesapplicationspringmvc.service;

import com.cg.testseriesapplicationspringmvc.dto.Test;

public interface TestService {
	public Test createMyTest(Test test);
	public Test searchTestByName(String testName);
	public Test searchTestById(int id);
}
