package com.cg.testseriesapplicationspringmvc.service;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;

public interface TestAssignerService {
	public Assigner assignTestToCandidate(Assigner assigner);
}
