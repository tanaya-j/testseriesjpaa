package com.cg.testseriesapplicationspringmvc.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.testseriesapplicationspringmvc.dto.Candidate;
import com.cg.testseriesapplicationspringmvc.exception.CandidateNotFoundException;
import com.cg.testseriesapplicationspringmvc.repository.CandidateRepositoryImp;

@Transactional
@Service
public class CandidateServiceImp implements CandidateService{
	@Autowired
	CandidateRepositoryImp dao;
	@Override
	public Candidate addCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
     return	dao.saveCandidate(candidate);
	}

	@Override
	public Candidate searchById(int id) {
		
		Candidate c=dao.findById(id);
		if(c==null) {
			throw new CandidateNotFoundException("ID NOT PRESENT");
		  }
		
		return c;
	}

}
