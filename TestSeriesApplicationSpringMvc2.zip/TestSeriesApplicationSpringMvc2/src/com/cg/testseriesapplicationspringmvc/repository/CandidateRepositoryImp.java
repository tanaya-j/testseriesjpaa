package com.cg.testseriesapplicationspringmvc.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.testseriesapplicationspringmvc.dto.Candidate;
import com.cg.testseriesapplicationspringmvc.util.DBUtilCandidate;

@Repository("CandidateRepository")
public class CandidateRepositoryImp implements CandidateRepository {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public Candidate saveCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
		em.persist(candidate);
		em.flush();
		return candidate;
	}

	@Override
	public Candidate findById(int id) {
		// TODO Auto-generated method stub
		return em.find(Candidate.class,id);
	}

}
