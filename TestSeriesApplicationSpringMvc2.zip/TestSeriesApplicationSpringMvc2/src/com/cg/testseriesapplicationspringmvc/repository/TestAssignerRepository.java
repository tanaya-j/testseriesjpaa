package com.cg.testseriesapplicationspringmvc.repository;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;

public interface TestAssignerRepository {
	public Assigner save(Assigner assigner); 
}
