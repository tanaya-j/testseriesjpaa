package com.cg.testseriesapplicationspringmvc.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;
import com.cg.testseriesapplicationspringmvc.dto.Candidate;
import com.cg.testseriesapplicationspringmvc.dto.Test;
import com.cg.testseriesapplicationspringmvc.util.DBUtilAssigner;

@Repository("AssignerRepository")
public class TestAssignerRepositoryImp implements TestAssignerRepository {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public Assigner save(Assigner assigner) {
		// TODO Auto-generated method stub
		Test test;
		Candidate cand;
		
	     test=em.find(Test.class, assigner.getTest().getId());
		 cand=em.find(Candidate.class, assigner.getCandidate().getId());
		
		 
		
		if(test!=null && cand!=null)
		{
		em.persist(assigner);
		em.flush();
	    }
		return assigner;
		}

}
