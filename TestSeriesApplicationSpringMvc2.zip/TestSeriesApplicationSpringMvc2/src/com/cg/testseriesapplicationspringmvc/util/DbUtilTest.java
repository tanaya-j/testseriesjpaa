package com.cg.testseriesapplicationspringmvc.util;

import java.util.ArrayList;

import java.util.List;



import com.cg.testseriesapplicationspringmvc.dto.Question;
import com.cg.testseriesapplicationspringmvc.dto.Test;




public class DbUtilTest {

//	public static Map<String,Test> myTests=new HashMap<String,Test>();
	public static List<Test> myTestList=new ArrayList<Test>();
	public static List<Question> myQuestionList=new ArrayList<Question>();
}
