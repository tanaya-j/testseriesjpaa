package com.cg.testseriesapplicationspringmvc.util;


import java.util.ArrayList;
import java.util.List;

import com.cg.testseriesapplicationspringmvc.dto.Assigner;



public class DBUtilAssigner {

	  public static List<Assigner> assigner  = new ArrayList<Assigner>();
}
