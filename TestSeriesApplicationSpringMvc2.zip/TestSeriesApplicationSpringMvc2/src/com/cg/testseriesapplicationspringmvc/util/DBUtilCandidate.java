package com.cg.testseriesapplicationspringmvc.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.testseriesapplicationspringmvc.dto.Candidate;


public class DBUtilCandidate {

	
	public static List<Candidate> myCandidates=new ArrayList<Candidate>();
}
