package com.cg.testseriesjpa.services;

import com.cg.testseriesjpa.dao.TestRepository;
import com.cg.testseriesjpa.dao.TestRepositoryImplements;
import com.cg.testseriesjpa.dto.Test;
import com.cg.testseriesjpa.exception.TestNotFoundException;

/*This class is implementation of test service interface which implements create test ,search test 
 * by name and id methods..!*/
public class TestServiceImplements implements TestService{
TestRepository dao;
	
	public TestServiceImplements() {
		
		dao= new TestRepositoryImplements();
	}
	
	//creates the test
	public void createMyTest(Test test) {
		// TODO Auto-generated method stub
		 dao.saveTest(test);
	}

	//search test by name
	public Test searchTestByName(String testName) {
		// TODO Auto-generated method stub
				return dao.findByName(testName);
	}

	//search test by Id
	public Test searchTestById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

}
