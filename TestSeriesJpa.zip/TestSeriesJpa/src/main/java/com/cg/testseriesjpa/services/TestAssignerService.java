package com.cg.testseriesjpa.services;

import com.cg.testseriesjpa.dto.Assigner;


/*
 * This is the test assigner interface which includes method that assigns test to candidate
 * */
public interface TestAssignerService {
	public Assigner assignTestToCandidate(Assigner assigner);
	
}
