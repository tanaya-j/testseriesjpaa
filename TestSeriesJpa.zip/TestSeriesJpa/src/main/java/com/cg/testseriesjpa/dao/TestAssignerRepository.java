package com.cg.testseriesjpa.dao;

import com.cg.testseriesjpa.dto.Assigner;

/*
 * This a Test assigner repository  interface  */
public interface TestAssignerRepository {
	public Assigner save(Assigner assigner); 
	
}
