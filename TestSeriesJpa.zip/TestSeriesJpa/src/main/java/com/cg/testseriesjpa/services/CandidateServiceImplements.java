package com.cg.testseriesjpa.services;

import com.cg.testseriesjpa.dao.CandidateRepositoryImp;
import com.cg.testseriesjpa.dto.Candidate;
import com.cg.testseriesjpa.exception.CandidateNotFoundException;

/*
 * This class is a implementation of candidate service*/
public class CandidateServiceImplements implements CandidateService {

	CandidateRepositoryImp dao;
	public CandidateServiceImplements() {
		dao=new CandidateRepositoryImp();}
	
	//add the candidate
	public void addCandidate(Candidate candidate) {
		// TODO Auto-generated method stub
		 dao.saveCandidate(candidate);
	}

	//search the candidate by Id
	public Candidate searchById(int id) {
		// TODO Auto-generated method stub
		
		return dao.findById(id);
	}

}
