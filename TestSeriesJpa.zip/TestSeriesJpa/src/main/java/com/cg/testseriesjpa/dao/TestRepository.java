package com.cg.testseriesjpa.dao;

import com.cg.testseriesjpa.dto.Test;

public interface TestRepository {
	public void saveTest(Test test);
	public Test findByName(String testName);
	public Test findById(int id);
}
