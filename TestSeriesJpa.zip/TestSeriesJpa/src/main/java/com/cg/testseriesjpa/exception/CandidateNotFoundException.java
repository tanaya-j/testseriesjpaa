package com.cg.testseriesjpa.exception;

public class CandidateNotFoundException extends RuntimeException {

	public  CandidateNotFoundException() {super();}
	public  CandidateNotFoundException(String msg) {super(msg);}
	
}
